document.addEventListener("DOMContentLoaded", function() {
    console.log("Página carregada! Adicione funcionalidades no script.js.");
});
